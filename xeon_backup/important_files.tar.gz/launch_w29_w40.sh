#!/bin/bash
# Launch W29-W40 wavefront calibration on Xeon
# Design: act_thresh [50,100] × K_half [200K,400K,600K] × T_vbnc [12,14]
# All: k_vbnc=2.0, s0=0.002, Penv=2000, D_P=50, D_P_max_range=500km

set -e
cd ~/projects/sswd-evoepi

# Pull latest code
git pull origin main

# Threading limits for parallel runs
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_MAX_THREADS=1
export NUMBA_THREADING_LAYER=omp
export NUMBA_NUM_THREADS=7
export PYTHONUNBUFFERED=1

for W in $(seq 29 40); do
    OUTDIR="results/calibration/W${W}"
    CFG="experiments/calibration/W${W}_config.json"
    
    if [ ! -f "$CFG" ]; then
        echo "Config $CFG not found, skipping"
        continue
    fi
    
    mkdir -p "$OUTDIR"
    
    echo "Launching W${W}..."
    nohup python3 experiments/calibration_runner.py \
        --config "$CFG" \
        --seeds 42 \
        --output "$OUTDIR" \
        > "$OUTDIR/run_seed42.log" 2>&1 &
    
    PID=$!
    echo "  PID=$PID → $OUTDIR/run_seed42.log"
    
    # Stagger launches by 10s to avoid I/O contention during network build
    sleep 10
done

echo ""
echo "All 12 launched. Monitor with:"
echo "  ps aux | grep calibration_runner | grep -v grep | wc -l"
echo "  tail -1 results/calibration/W*/run_seed42.log"
