#!/bin/bash
cd ~/projects/sswd-evoepi

echo "=== Relaunching ALL 18 calibration runs ==="
echo "$(date)"

for ROUND in 00 01 02 03 04 05; do
    for SEED in 42 123 999; do
        nohup python3 -u experiments/calibration_runner.py \
            --config results/calibration/round_${ROUND}/params.json \
            --seed $SEED \
            --output results/calibration/round_${ROUND}/ \
            --K 5000 \
            > results/calibration/round_${ROUND}/run_seed${SEED}.log 2>&1 &
        echo "R${ROUND} seed ${SEED}: PID $!"
    done
done

echo ""
echo "Total processes: $(ps aux | grep calibration_runner | grep python | grep -v grep | wc -l)"
echo "$(date)"
