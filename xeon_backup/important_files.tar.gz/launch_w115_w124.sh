#!/bin/bash
# W115-W124: T_vbnc_min=9-10°C sweep
# Per-seed parallelism: 10 configs × 3 seeds = 30 jobs, ~20 parallel

cd ~/projects/sswd-evoepi
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_MAX_THREADS=1
export NUMBA_THREADING_LAYER=omp
export NUMBA_NUM_THREADS=3
export PYTHONUNBUFFERED=1

MAX_PARALLEL=20

run_one() {
    local name=$1
    local seed=$2
    local config_path="experiments/calibration/${name}_config.json"
    local output_dir="results/calibration/${name}"
    
    mkdir -p "$output_dir"
    echo "[$(date)] Starting $name seed=$seed"
    python3 experiments/calibration_runner.py \
        --config "$config_path" \
        --seeds $seed \
        --output "$output_dir/" \
        > "$output_dir/stdout_seed${seed}.log" 2>&1
    echo "[$(date)] Finished $name seed=$seed (exit=$?)"
}

CONFIGS=(W115 W116 W117 W118 W119 W120 W121 W122 W123 W124)
SEEDS=(42 123 999)

for cfg in "${CONFIGS[@]}"; do
    for seed in "${SEEDS[@]}"; do
        while [ $(jobs -r | wc -l) -ge $MAX_PARALLEL ]; do
            sleep 30
        done
        run_one "$cfg" "$seed" &
    done
done

wait
echo "[$(date)] All W115-W124 complete!"

# Combine results per config
for cfg in "${CONFIGS[@]}"; do
    python3 experiments/calibration/format_results.py \
        "results/calibration/${cfg}/" 2>/dev/null
done
echo "[$(date)] Results formatted."
