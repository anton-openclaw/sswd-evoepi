#!/bin/bash
# W105-W114 calibration: virulence evolution + s0 sweep
# 10 configs × 3 seeds = 30 runs, 6 parallel at a time

cd ~/projects/sswd-evoepi
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_MAX_THREADS=1
export NUMBA_THREADING_LAYER=omp
export NUMBA_NUM_THREADS=7
export PYTHONUNBUFFERED=1

SEEDS="42,123,999"
MAX_PARALLEL=6

run_config() {
    local name=$1
    local config_path="experiments/calibration/${name}_config.json"
    local output_dir="results/calibration/${name}"
    
    mkdir -p "$output_dir"
    echo "[$(date)] Starting $name"
    python3 experiments/calibration_runner.py \
        --config "$config_path" \
        --seeds $SEEDS \
        --output "$output_dir/" \
        > "$output_dir/stdout.log" 2>&1
    echo "[$(date)] Finished $name (exit=$?)"
}

# Launch in batches of MAX_PARALLEL
CONFIGS=(W105 W106 W107 W108 W109 W110 W111 W112 W113 W114)

for cfg in "${CONFIGS[@]}"; do
    # Wait if we have MAX_PARALLEL background jobs
    while [ $(jobs -r | wc -l) -ge $MAX_PARALLEL ]; do
        sleep 30
    done
    run_config "$cfg" &
done

# Wait for all to finish
wait
echo "[$(date)] All W105-W114 complete!"
