#!/bin/bash
cd ~/projects/sswd-evoepi
nohup python3 -u scripts/sensitivity/run_sobol_r4.py >> results/sensitivity_r4/sobol_log_prentice.txt 2>&1 &
echo "PID: $!"
