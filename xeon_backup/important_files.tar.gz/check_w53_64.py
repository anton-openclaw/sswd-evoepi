import json, os

targets = ["AK-PWS", "AK-FN", "AK-FS", "BC-N", "SS-S", "JDF", "OR", "CA-N"]
base = os.path.expanduser("~/projects/sswd-evoepi")

for wnum in range(53, 65):
    wid = f"W{wnum:02d}"
    rpath = os.path.join(base, f"results/calibration/{wid}/combined_results.json")
    
    if not os.path.exists(rpath):
        print(f"{wid}: INCOMPLETE (running)")
        continue
    
    d = json.load(open(rpath))
    r = d["results"]
    if isinstance(r, list):
        r = r[0]
    
    overrides = d.get("param_overrides", {})
    rec = r.get("region_recovery", {})
    arrival = r.get("arrival_timing", {}).get("per_region", {})
    
    # Key params
    wf_dp = overrides.get("disease.wavefront_D_P", "N/A")
    wf_range = overrides.get("disease.wavefront_D_P_max_range", "N/A")
    penv = overrides.get("disease.P_env_max", "N/A")
    cdt = overrides.get("disease.cumulative_dose_threshold", "N/A")
    
    # Recovery for target regions
    vals = []
    for reg in targets:
        pct = rec.get(reg, -1)
        if pct >= 0:
            vals.append(f"{pct*100:.1f}")
        else:
            vals.append("N/A")
    
    # Arrival months for key AK regions
    ak_pws_arr = arrival.get("AK-PWS", {}).get("actual_months", "N/A")
    ak_fs_arr = arrival.get("AK-FS", {}).get("actual_months", "N/A")
    mae = r.get("arrival_timing", {}).get("mae_months", "N/A")
    
    param_str = f"wfDP={wf_dp} wfRange={wf_range} Penv={penv} CDT={cdt}"
    rec_str = " | ".join(f"{t}={v}" for t, v in zip(targets, vals))
    
    print(f"{wid} | {param_str}")
    print(f"  Recovery%: {rec_str}")
    print(f"  Arrival: AK-FS={ak_fs_arr}mo AK-PWS={ak_pws_arr}mo | MAE={mae}mo")
    print()
