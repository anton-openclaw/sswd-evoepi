#!/bin/bash
# Launch W41-W44 calibration on Xeon (cumulative dose threshold sweep)
# Each round: single seed (42), ~8-12h each

set -e

cd ~/projects/sswd-evoepi
git pull origin main

export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_MAX_THREADS=1
export NUMBA_THREADING_LAYER=omp
export NUMBA_NUM_THREADS=7
export PYTHONUNBUFFERED=1

for ROUND in W41 W42 W43 W44; do
    CONFIG="experiments/calibration/${ROUND}_config.json"
    OUTDIR="results/calibration/${ROUND}"
    LOG="results/calibration/${ROUND}_log.txt"
    
    mkdir -p "$OUTDIR"
    
    echo "Launching $ROUND..."
    nohup python3 experiments/calibration_runner.py \
        --config "$CONFIG" \
        --seed 42 \
        --output "$OUTDIR" \
        --K 5000 \
        --years 13 \
        --disease-year 1 \
        > "$LOG" 2>&1 &
    
    echo "  PID: $! → $LOG"
    sleep 2
done

echo ""
echo "All 4 launched. Check with: ps aux | grep calibration_runner"
echo "Logs: results/calibration/W4*_log.txt"
