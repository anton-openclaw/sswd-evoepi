#!/bin/bash
set -e
cd ~/projects/sswd-evoepi
git pull origin main

export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_MAX_THREADS=1
export NUMBA_THREADING_LAYER=omp NUMBA_NUM_THREADS=7 PYTHONUNBUFFERED=1

for ROUND in W45 W46 W47 W48 W49 W50 W51 W52; do
    OUTDIR="results/calibration/${ROUND}"
    mkdir -p "$OUTDIR"
    echo "Launching $ROUND..."
    nohup python3 experiments/calibration_runner.py \
        --config "experiments/calibration/${ROUND}_config.json" \
        --seed 42 --output "$OUTDIR" --K 5000 --years 13 --disease-year 1 \
        > "results/calibration/${ROUND}_log.txt" 2>&1 &
    echo "  PID: $!"
    sleep 2
done
echo "All 8 launched."
