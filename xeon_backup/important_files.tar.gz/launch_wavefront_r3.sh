#!/bin/bash
# Launch wavefront calibration W17-W28 on Xeon
# 12 rounds × seed=42 first pass

set -e
cd ~/projects/sswd-evoepi
git pull

export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_MAX_THREADS=1
export NUMBA_THREADING_LAYER=omp
export NUMBA_NUM_THREADS=5
export PYTHONUNBUFFERED=1

RESULTS_BASE="results/calibration"

echo "=== Wavefront Calibration Round 3: W17-W28 ==="
echo "Time: $(date)"
echo "12 rounds, seed=42 first pass"
echo ""

for ROUND in W17 W18 W19 W20 W21 W22 W23 W24 W25 W26 W27 W28; do
    OUTDIR="${RESULTS_BASE}/${ROUND}"
    CONFIG="experiments/calibration/${ROUND}_config.json"
    LOG="${OUTDIR}/run_seed42.log"
    
    mkdir -p "$OUTDIR"
    
    echo "Launching ${ROUND}..."
    nohup python3 experiments/calibration_runner.py \
        --config "$CONFIG" \
        --seed 42 \
        --K 5000 \
        --years 13 \
        --disease-year 1 \
        --output "$OUTDIR" \
        > "$LOG" 2>&1 &
    
    echo "  PID=$! → ${LOG}"
    sleep 2
done

echo ""
echo "All 12 launched. Monitor with:"
echo "  ps aux | grep calibration_runner | grep -v grep | wc -l"
echo "  tail -1 results/calibration/W*/run_seed42.log"
