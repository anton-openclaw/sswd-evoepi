#!/bin/bash
# Launch wavefront calibration W05-W16 on Xeon
# 12 rounds × 1 seed first (seed=42) for fast feedback
# Then 2 more seeds per round after reviewing results

set -e
cd ~/projects/sswd-evoepi

export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_MAX_THREADS=1
export NUMBA_THREADING_LAYER=omp
export NUMBA_NUM_THREADS=5
export PYTHONUNBUFFERED=1

RESULTS_BASE="results/calibration"

echo "=== Wavefront Calibration Round 2: W05-W16 ==="
echo "Time: $(date)"
echo "12 rounds, seed=42 first pass"
echo ""

for ROUND in W05 W06 W07 W08 W09 W10 W11 W12 W13 W14 W15 W16; do
    OUTDIR="${RESULTS_BASE}/${ROUND}"
    CONFIG="experiments/calibration/${ROUND}_config.json"
    LOG="${OUTDIR}/run_seed42.log"
    
    mkdir -p "$OUTDIR"
    
    echo "Launching ${ROUND}..."
    nohup python3 experiments/calibration_runner.py \
        --config "$CONFIG" \
        --seed 42 \
        --K 5000 \
        --years 13 \
        --disease-year 1 \
        --output "$OUTDIR" \
        > "$LOG" 2>&1 &
    
    echo "  PID=$! → ${LOG}"
    sleep 2  # stagger launches slightly
done

echo ""
echo "All 12 launched. Monitor with:"
echo "  ps aux | grep calibration_runner | grep -v grep | wc -l"
echo "  tail -1 results/calibration/W*/run_seed42.log"
echo ""
echo "Expected ~10-15h per run on 64 cores with 12 parallel."
