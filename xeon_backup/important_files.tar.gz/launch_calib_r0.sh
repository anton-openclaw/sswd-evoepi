#!/bin/bash
# Launch calibration Round 0 (baseline) on Xeon — 3 seeds
cd ~/projects/sswd-evoepi
echo "=== Calibration Round 0 (baseline defaults) ==="
echo "Started: $(date)"

python3 -u experiments/calibration_runner.py \
    --config results/calibration/round_00/params.json \
    --seeds 42,123,999 \
    --output results/calibration/round_00/ \
    --K 5000 \
    --years 14 \
    > results/calibration/round_00/run.log 2>&1

echo "Finished: $(date)"
echo "Exit code: $?"
