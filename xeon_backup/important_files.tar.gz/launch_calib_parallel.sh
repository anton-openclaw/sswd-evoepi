#!/bin/bash
# Launch calibration runs in parallel on Xeon
# Each seed runs as a separate process

cd ~/projects/sswd-evoepi

echo "=== Parallel Calibration Launch ==="
echo "Started: $(date)"
echo "Cores: $(nproc), RAM: $(free -g | awk '/Mem/{print $2}')GB"

# Round 00 — defaults, 3 seeds in parallel
for SEED in 42 123 999; do
    echo "Launching Round 00, seed $SEED..."
    nohup python3 -u experiments/calibration_runner.py \
        --config results/calibration/round_00/params.json \
        --seed $SEED \
        --output results/calibration/round_00/ \
        --K 5000 \
        > results/calibration/round_00/run_seed${SEED}.log 2>&1 &
    echo "  PID: $!"
done

# Round 01 — lower K_half (stronger density-dependent transmission)
mkdir -p results/calibration/round_01
echo '{"disease.K_half": 30000}' > results/calibration/round_01/params.json
for SEED in 42 123 999; do
    echo "Launching Round 01 (K_half=30000), seed $SEED..."
    nohup python3 -u experiments/calibration_runner.py \
        --config results/calibration/round_01/params.json \
        --seed $SEED \
        --output results/calibration/round_01/ \
        --K 5000 \
        > results/calibration/round_01/run_seed${SEED}.log 2>&1 &
    echo "  PID: $!"
done

# Round 02 — higher K_half (weaker density-dependent transmission)
mkdir -p results/calibration/round_02
echo '{"disease.K_half": 200000}' > results/calibration/round_02/params.json
for SEED in 42 123 999; do
    echo "Launching Round 02 (K_half=200000), seed $SEED..."
    nohup python3 -u experiments/calibration_runner.py \
        --config results/calibration/round_02/params.json \
        --seed $SEED \
        --output results/calibration/round_02/ \
        --K 5000 \
        > results/calibration/round_02/run_seed${SEED}.log 2>&1 &
    echo "  PID: $!"
done

# Round 03 — lower P_env_max (less environmental pathogen)
mkdir -p results/calibration/round_03
echo '{"disease.P_env_max": 100}' > results/calibration/round_03/params.json
for SEED in 42 123 999; do
    echo "Launching Round 03 (P_env_max=100), seed $SEED..."
    nohup python3 -u experiments/calibration_runner.py \
        --config results/calibration/round_03/params.json \
        --seed $SEED \
        --output results/calibration/round_03/ \
        --K 5000 \
        > results/calibration/round_03/run_seed${SEED}.log 2>&1 &
    echo "  PID: $!"
done

# Round 04 — higher P_env_max (more environmental pathogen)  
mkdir -p results/calibration/round_04
echo '{"disease.P_env_max": 2000}' > results/calibration/round_04/params.json
for SEED in 42 123 999; do
    echo "Launching Round 04 (P_env_max=2000), seed $SEED..."
    nohup python3 -u experiments/calibration_runner.py \
        --config results/calibration/round_04/params.json \
        --seed $SEED \
        --output results/calibration/round_04/ \
        --K 5000 \
        > results/calibration/round_04/run_seed${SEED}.log 2>&1 &
    echo "  PID: $!"
done

# Round 05 — combo: lower K_half + lower P_env_max (less severe crash)
mkdir -p results/calibration/round_05
echo '{"disease.K_half": 200000, "disease.P_env_max": 100, "disease.a_exposure": 0.3}' > results/calibration/round_05/params.json
for SEED in 42 123 999; do
    echo "Launching Round 05 (mild disease), seed $SEED..."
    nohup python3 -u experiments/calibration_runner.py \
        --config results/calibration/round_05/params.json \
        --seed $SEED \
        --output results/calibration/round_05/ \
        --K 5000 \
        > results/calibration/round_05/run_seed${SEED}.log 2>&1 &
    echo "  PID: $!"
done

echo ""
echo "Launched 18 parallel runs (6 rounds × 3 seeds)"
echo "Processes:"
ps aux | grep calibration_runner | grep -v grep | wc -l
echo "$(date)"
