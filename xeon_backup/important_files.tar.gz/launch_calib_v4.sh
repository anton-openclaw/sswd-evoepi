#!/bin/bash
# Calibration launcher v4 — Numba parallel via OpenMP
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_MAX_THREADS=1
export NUMBA_THREADING_LAYER=omp
export NUMBA_NUM_THREADS=7  # 18 processes × 7 = 126 threads on 128 cores

cd ~/projects/sswd-evoepi

SEEDS="42 123 999"

declare -A CONFIGS
CONFIGS[round_00]="{}"
CONFIGS[round_01]="{\"disease.K_half\": 30000}"
CONFIGS[round_02]="{\"disease.K_half\": 200000}"
CONFIGS[round_03]="{\"disease.P_env_max\": 100}"
CONFIGS[round_04]="{\"disease.P_env_max\": 2000}"
CONFIGS[round_05]="{\"disease.K_half\": 200000, \"disease.P_env_max\": 100, \"disease.a_exposure\": 0.3}"

for round in round_00 round_01 round_02 round_03 round_04 round_05; do
    OUTDIR="results/calibration/${round}"
    mkdir -p "$OUTDIR"
    CONFIG_FILE="$OUTDIR/config.json"
    echo "${CONFIGS[$round]}" > "$CONFIG_FILE"
    
    for seed in $SEEDS; do
        LOG="$OUTDIR/seed_${seed}.log"
        echo "Launching ${round} seed=${seed}..."
        nohup python3 experiments/calibration_runner.py \
            --config "$CONFIG_FILE" \
            --seed $seed \
            --output "$OUTDIR" \
            --K 5000 \
            --years 13 \
            --disease-year 1 \
            > "$LOG" 2>&1 &
    done
done

echo "All 18 launched."
echo "PIDs:"
pgrep -f calibration_runner | head -20
